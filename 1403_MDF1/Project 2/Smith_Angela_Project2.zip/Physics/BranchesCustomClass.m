//
//  BranchesCustomClass.m
//  Physics
//
//  Created by Angela Smith on 3/10/14.
//  Copyright (c) 2014 Angela Smith. All rights reserved.
//

#import "BranchesCustomClass.h"

@implementation BranchesCustomClass
// synthesize the properties
@synthesize branchIntro, branchTitle, firstbranch, secondBranch, thirdBranch;
@end
