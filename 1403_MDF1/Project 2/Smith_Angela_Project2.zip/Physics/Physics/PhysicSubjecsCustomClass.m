//
//  PhysicSubjecsCustomClass.m
//  Physics
//
//  Created by Angela Smith on 3/8/14.
//  Copyright (c) 2014 Angela Smith. All rights reserved.
//

#import "PhysicSubjecsCustomClass.h"

@implementation PhysicSubjecsCustomClass
// Synthesize the property variables
@synthesize subjectDescription, subjectImage, subjectName, subjectSubTitle, subjectExample, formula, formulaNotes, formulaValue, formulaX, formulaY;
@end
