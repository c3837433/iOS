//
//  ResearchCustomClass.m
//  Physics
//
//  Created by Angela Smith on 3/8/14.
//  Copyright (c) 2014 Angela Smith. All rights reserved.
//

#import "ResearchCustomClass.h"

@implementation ResearchCustomClass
// Synthesize the properties for the research class
@synthesize researchReference, researchSummary, researchTitle, researchUrl;
@end
