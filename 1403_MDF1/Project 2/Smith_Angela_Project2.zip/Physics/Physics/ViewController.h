//
//  ViewController.h
//  Physics
//
//  Created by Angela Smith on 3/7/14.
//  Copyright (c) 2014 Angela Smith. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UILabel* branchTitle;
    IBOutlet UILabel* branchIntro;
    IBOutlet UILabel* branch1;
    IBOutlet UILabel* branch2;
    IBOutlet UILabel* branch3;
}

@end
